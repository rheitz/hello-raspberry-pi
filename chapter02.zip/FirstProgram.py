message = "And now for something completely different."
print(message)
