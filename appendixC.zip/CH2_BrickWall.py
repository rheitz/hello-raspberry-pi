# Brick Wall
# Ryan Heitz
# Display a pattern that looks like a brick wall

brick = "|__"
print(brick * 1000)
