# The Matrix
# Ryan Heitz
# Display a screen full of 1s and 0s

matrix = "0100101101001100100110001011001011110000010101"
print(matrix * 100)
