# Brick Wall
# Ryan Heitz
# Display a pattern that looks like a brick wall

brick = "|_o88{_" 
print(brick*300)

